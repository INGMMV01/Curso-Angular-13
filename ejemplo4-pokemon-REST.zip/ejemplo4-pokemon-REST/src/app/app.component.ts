import { Component } from '@angular/core';
import { PokemonService } from './services/pokemon.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  pokemons: any[] = [];
  next: string = "";
  previous: string = "";
  atrasDeshabilitado: boolean = true;
  adelanteDeshabilitado: boolean = true;
  nombre: string = "";
  pokemon: any;
  
  constructor(private pokemonService: PokemonService){
    
    // Esto no se puede hacer
    // this.pokemons = pokemonService.getAll();

    // Me subscribo al observable atenta a recibir los datos
    pokemonService.getAll().subscribe( (datos) => {
      this.pokemons = datos.results;
      this.next = datos.next;
    } );
  }

  buscar(){
    this.pokemonService.buscarPokemon(this.nombre).subscribe((item) => {
      console.log(item);
      this.pokemon = item;
    });
  }

  atras(){
    this.pokemonService.emitirPeticion(this.previous).subscribe( (datos) => {
      this.pokemons = datos.results;
      this.next = datos.next;
      this.previous = datos.previous;
      if (this.previous == null){
        this.atrasDeshabilitado = true;
      }
    });
  }

  adelante(){
    this.pokemonService.emitirPeticion(this.next).subscribe( (datos) => {
      this.pokemons = datos.results;
      this.next = datos.next;
      this.previous = datos.previous;
      this.atrasDeshabilitado = false;
    });
  }


}
