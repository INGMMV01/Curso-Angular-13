import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AgendaService {

  private amigos: any[] = [
    {id:1, nombre:"Juan", telefono: "616111111"},
    {id:2, nombre:"Maria", telefono: "616222222"}
  ];

  constructor() { }

  modificar(amigo: any): void{
    this.amigos.forEach( (item) => {
      if (item.id == amigo.id){
        item.nombre = amigo.nombre;
        item.telefono = amigo.telefono;
      }
    });
  }

  eliminar(id: number){
    //this.amigos = this.amigos.filter(item => item.id != id);
    
    // 1º opcion para buscar el indice del elemento a eliminar
    /*
    let encontrado: number = 0;
    for (let idx=0; idx < this.amigos.length; idx++){
      if (this.amigos[idx].id == id){
        encontrado = idx;
        break;
      }
    }*/
     
    // 2º opcion para buscar el indice del elemento a eliminar
    let encontrado =this.amigos.findIndex(item => item.id == id)
    this.amigos.splice(encontrado, 1);
  }

  buscarAmigoId(id: number){
    return this.amigos.filter((item) => {
      return item.id == id;
    })[0];
  }

  buscarAmigoNombre(nombre: string){
    return this.amigos.filter((item) => {
      return item.nombre == nombre;
    })[0];
  }

  getAll(): any[]{
    return this.amigos;
  }

  nuevoAmigo(nuevo: any){
    this.amigos.push(nuevo);
  }
}
