import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AgendaService {

  private amigos: any[] = [
    {id:1, nombre:"Juan", telefono: "616111111"},
    {id:2, nombre:"Maria", telefono: "616222222"}
  ];

  constructor() { }

  getAll(): any[]{
    return this.amigos;
  }

  nuevoAmigo(nuevo: any){
    this.amigos.push(nuevo);
  }
}
