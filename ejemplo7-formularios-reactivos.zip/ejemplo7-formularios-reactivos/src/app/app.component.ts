import { Component, OnInit } from '@angular/core';
import { AgendaService } from './services/agenda.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  
  amigos: any[] = [];

  amigoForm = new FormGroup({
    id: new FormControl(0, [Validators.required, Validators.min(1)]),
    nombre: new FormControl('', [Validators.required, Validators.minLength(3)]),
    telefono: new FormControl('', [Validators.required, Validators.pattern('[6-7]{1}[0-9]{8}')])
  });

  constructor(private agendaService: AgendaService){}

  alta(): void{
    this.agendaService.nuevoAmigo(this.amigoForm.value);
    // limpiar el formulario
    this.amigoForm.reset();
  }

  ngOnInit(): void {
    this.amigos = this.agendaService.getAll();
  }
}
