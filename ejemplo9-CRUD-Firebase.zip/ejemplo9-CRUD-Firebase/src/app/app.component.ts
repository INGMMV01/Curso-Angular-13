import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AgendaService } from './services/agenda.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  amigos: any[] = [];
  nombre: string = '';
  id: string = '';
  contacto: any;

  amigoForm = new FormGroup({
    nombre: new FormControl('', [Validators.required, Validators.minLength(3)]),
    telefono: new FormControl('', [Validators.required, Validators.pattern('[6-7]{1}[0-9]{8}')])
  });

  constructor(private agendaService: AgendaService){
    this.agendaService.getAll().subscribe((datos) => {
      //console.log(datos);

      // limpiamos el array
      this.amigos = [];

      datos.forEach(item => {
      //  console.log(item.payload.doc.data());
        this.amigos.push(item.payload.doc.data());
      });
    });  
  }

  modificar(){
    this.agendaService.modificar(this.id, this.amigoForm.value)
      .then(() => {
        this.contacto = null;
        this.amigoForm.reset();
        this.id = '';
      })
      .catch((error) => {
        console.log(error);
      });
  }

  eliminar(){
    this.agendaService.eliminar(this.id).then(() => {
      this.contacto = null;
      this.amigoForm.reset();
      this.id = '';
    })
    .catch((error) => {
      console.log(error);
    });
  }

  buscar(): void{
    this.agendaService.buscarAmigoId(this.id).subscribe((item) => {
      console.log(item.payload.id);
      console.log(item.payload.data());
      this.contacto = item.payload.data();
      if (this.contacto != undefined){
        this.amigoForm.setValue(this.contacto);
      }
    }); 
  }

  alta(): void{
    this.agendaService.nuevoAmigo(this.amigoForm.value)
      .then(() => {
        // limpiar el formulario
        this.amigoForm.reset();
      } )
      .catch((error) => {
        console.log(error);
      });
  }
    
}
