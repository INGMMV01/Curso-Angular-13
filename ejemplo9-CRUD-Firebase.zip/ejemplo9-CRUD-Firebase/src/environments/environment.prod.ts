export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyD937LY6hjdmuq4J_dkDYxBdDbvlCBG198",
    authDomain: "angular14anabel.firebaseapp.com",
    projectId: "angular14anabel",
    storageBucket: "angular14anabel.appspot.com",
    messagingSenderId: "923821754678",
    appId: "1:923821754678:web:46330120159c8b87a04b97"
  }
};
