import { Directive, HostBinding, HostListener } from '@angular/core';

@Directive({
  selector: '[appContarClicks]'
})
export class ContarClicksDirective {

  numeroClicks: number = 0;

  @HostBinding('style.font-size') // tambien funciona con style.fontSize
  size: string = '';

  @HostBinding('style.opacity')
  opacidad: number = 0.1;

  constructor() { }

  // Queremos es detectar el evento click
  @HostListener('click')
  onClick(): void{
    this.numeroClicks++;
    this.size = (20 + this.numeroClicks + "px");
    this.opacidad += 0.1;
  }

}
