import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-c3',
  templateUrl: './c3.component.html',
  styleUrls: ['./c3.component.css']
})
export class C3Component implements OnInit {
  
  hotel: string = '';
  entrada: string = '';
  salida: string = '';
  habitaciones: number = 0;

  // En el constructor inyectamos los recursos que vamos a necesitar
  constructor(private ruta: ActivatedRoute) { 

    console.log(this.ruta);

    // Recuperar el parametro de la ruta
    // Con el mismo nombre que se ha declarado en app.module.ts
    this.hotel = this.ruta.snapshot.params['hotel'];

    // Recuperar los query params
    this.entrada = this.ruta.snapshot.queryParams['entrada'];
    this.salida = this.ruta.snapshot.queryParams['salida'];
    this.habitaciones = this.ruta.snapshot.queryParams['habitaciones'];
  }

  ngOnInit(): void {
  }

}
