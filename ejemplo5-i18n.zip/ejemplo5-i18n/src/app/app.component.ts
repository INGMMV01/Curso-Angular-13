import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  idioma: string = "es";

  constructor(private translateService: TranslateService){
    // Indicar el idioma por defecto de la aplicacion
    this.translateService.setDefaultLang("es");
  }

  cambiarIdioma(nuevoIdioma: string): void{
    this.idioma = nuevoIdioma;
    
    // Forzamos el cambio de idioma
    this.translateService.use(this.idioma);
  }
}
