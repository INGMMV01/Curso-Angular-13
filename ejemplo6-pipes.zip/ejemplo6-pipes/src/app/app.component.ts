import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  texto: string = "Bienvenidos al curso de Angular";

  persona: Object = {
    "nombre": "Pepito", "apellido": "Perez",
    "edad": 36, "telefonos": { "tel1": 914123675, "tel2": 616123456 }
  };

  numero: number = 76543235677.76927272567;
  porcentaje: number = 0.537655;

  // Funciona de cualquiera de las 3 formas
  fecha: Date = new Date();
  //fecha: Date = new Date('8/25/2024'); //mes/dia/año
  //fecha: string = '8/25/2024';
}
