import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-contacto',
  templateUrl: './contacto.component.html',
  styleUrls: ['./contacto.component.css']
})
export class ContactoComponent implements OnInit {

  contactoForm = new FormGroup({
    asunto: new FormControl(''),
    email: new FormControl(''),
    telefono: new FormControl(''),
    texto: new FormControl('')
  });

  constructor() { }

  enviar(){
    console.log(this.contactoForm.value);
  }

  limpiar(){
    this.contactoForm.reset();
  }

  ngOnInit(): void {
  }

}
